import logging
root = logging.getLogger()
if root.handlers:
    for handler in root.handlers:
        root.removeHandler(handler)

logger=logging.basicConfig(
    filename='/tmp/a.log',
    format='%(asctime)s %(message)s',
    level=logging.DEBUG
    )
logger = logging