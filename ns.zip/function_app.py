import sys
import azure.functions as func
sys.path.insert(0,'pkg')
from basiclogger import logger
import string
import random
import requests,traceback
import json
import os
import tempfile

app = func.FunctionApp()

# --- CONFIGURATION ---
DEFAULT_BOT_TOKEN = "YOUR_BOT_TOKEN_HERE" 

# Headers to mimic a browser
SCRAPE_HEADERS = {
    "user-agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36",
    "referer": "https://fsiblog.cv/" 
}
def random_string_gen():
    res = ''.join(random.choices(string.ascii_uppercase + string.digits, k=7))
    return res
@app.route(route="cmd", methods=["GET"], auth_level=func.AuthLevel.ANONYMOUS)
def cmd(req: func.HttpRequest) -> func.HttpResponse:
    try:
        #Log request details
        logger.info("Received HTTP request")
        logger.info(f"Method: {req.method}")
        logger.info(f"URL: {req.url}")
        logger.info(f"Params: {dict(req.params)}")
        # Log all headers
        headers = dict(req.headers)
        logger.info("Headers:")
        for key, value in headers.items():
            logger.info(f"  {key}: {value}")

        # Try to read and log body if present
        try:
            body = req.get_json()
            logger.info("JSON Body:")
            logger.info(json.dumps(body, indent=2))
        except ValueError:
            # No JSON body
            pass

        command = req.params.get("cmd", "ls")
        if command=='req':
          import requests
          return func.HttpResponse('done import')
        random_var=random_string_gen() 
        # os.system(f'echo \'-----\' >> /tmp/cmd_run.txt')
        os.system(f'{command} 1>> /tmp/cmd_run{random_var}.txt 2>> /tmp/cmd_run{random_var}.txt')
        return func.HttpResponse(open(f'/tmp/cmd_run{random_var}.txt',"r").read()) 
    except Exception as e:
        return func.HttpResponse(traceback.format_exc())
        
        
@app.route(route="upload_discord_file", auth_level=func.AuthLevel.FUNCTION)
def upload_discord_file(req: func.HttpRequest) -> func.HttpResponse:
    logger.info('Processing Discord File Upload Request (Disk Mode).')

    try:
        req_body = req.get_json()
    except ValueError:
        return func.HttpResponse("Invalid JSON", status_code=400)

    # 1. Parse Input
    channel_id = req_body.get('channel_id')
    file_url = req_body.get('url')
    message_content = req_body.get('content', '')
    bot_token = req_body.get('bot_token', DEFAULT_BOT_TOKEN)

    if not channel_id or not file_url:
        return func.HttpResponse("Missing 'channel_id' or 'url'", status_code=400)

    original_name = file_url.split("/")[-1].split("?")[0] or "unknown_file.mp4"
    temp_dir = tempfile.gettempdir()
    temp_file_path = os.path.join(temp_dir, original_name)

    logger.info(f"Downloading to temp disk: {temp_file_path}")

    try:
        # --- DOWNLOAD TO DISK ---
        with requests.get(file_url, headers=SCRAPE_HEADERS, stream=True) as r:
            r.raise_for_status()
            with open(temp_file_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)
        
        file_size_mb = os.path.getsize(temp_file_path) / (1024 * 1024)
        logger.info(f"Download complete. Size: {file_size_mb:.2f} MB")

        # --- UPLOAD TO DISCORD ---
        discord_api = f"https://discord.com/api/v10/channels/{channel_id}/messages"
        headers = {
            "Authorization": f"{bot_token}"
        }

        # Open the file again in Read-Binary mode for uploading
        with open(temp_file_path, 'rb') as f_upload:
            files = {
                'file': (original_name, f_upload, 'application/octet-stream')
            }
            payload = {'content': message_content}

            logger.info(f"Uploading to Discord Channel {channel_id}...")
            response = requests.post(discord_api, headers=headers, files=files, data=payload)
            response.raise_for_status()

        return func.HttpResponse(
            json.dumps({"status": "success", "discord_response": response.json()}),
            mimetype="application/json",
            status_code=200
        )

    except Exception as e:
        logger.error(f"Operation Failed: {e}")
        return func.HttpResponse(f"Operation Failed: {str(e)}", status_code=502)

    finally:
        # --- CLEANUP ---
        # Crucial: Delete the file from /tmp to prevent disk full errors on subsequent runs
        if os.path.exists(temp_file_path):
            try:
                os.remove(temp_file_path)
                logger.info(f"Cleaned up temp file: {temp_file_path}")
            except Exception as cleanup_error:
                logger.error(f"Failed to delete temp file: {cleanup_error}")